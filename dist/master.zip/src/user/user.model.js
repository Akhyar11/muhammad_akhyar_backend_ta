"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.userModel = exports.UserSchema = void 0;
const jsonHandler_1 = __importDefault(require("../../jsonORM/jsonHandler"));
// User schema definition
exports.UserSchema = {
    id: "string",
    username: "string",
    password: "string",
    jk: "boolean",
    tgl_lahir: "string",
    token: "string",
    iotIsAllowed: "boolean",
};
exports.userModel = new jsonHandler_1.default("user", exports.UserSchema);
